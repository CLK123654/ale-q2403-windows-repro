from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Independent replay for the cache-fill point-process task")
    parser.add_argument("--input-root", required=True)
    parser.add_argument("--results-root", required=True)
    return parser.parse_args()


def reset_results(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)


def read_inputs(input_root: Path) -> tuple[dict, np.ndarray, np.ndarray, np.ndarray, np.ndarray, list[str]]:
    contract = json.loads((input_root / "model_contract.json").read_text(encoding="utf-8"))
    with (input_root / "cache_fill_bins.csv").open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        columns = list(reader.fieldnames or [])
        rows = list(reader)
    required_columns = list(contract["required_columns"])
    require(columns == required_columns, "input columns or order differ from contract")
    require(len(rows) == int(contract["bin_count"]), "bin count differs from contract")
    try:
        bin_id = np.array([int(row["bin_id"]) for row in rows], dtype=np.int64)
        time_seconds = np.array([float(row["time_seconds"]) for row in rows], dtype=np.float64)
        cache_pressure = np.array([float(row["cache_pressure"]) for row in rows], dtype=np.float64)
        dispatch_event = np.array([int(row["dispatch_event"]) for row in rows], dtype=np.int64)
    except (TypeError, ValueError) as error:
        raise ValueError("input contains an invalid numeric value") from error
    n = int(contract["bin_count"])
    dt = float(contract["bin_width_seconds"])
    require(np.array_equal(bin_id, np.arange(1, n + 1)), "bin_id must be continuous from one")
    require(np.all(np.isfinite(time_seconds)) and np.max(np.abs(time_seconds - bin_id * dt)) <= 1e-12, "time grid differs from contract")
    require(np.all(np.isfinite(cache_pressure)), "cache_pressure contains a non-finite value")
    require(np.all((dispatch_event == 0) | (dispatch_event == 1)), "dispatch_event must be binary")
    require(int(dispatch_event.sum()) == int(contract["event_count"]), "event count differs from contract")
    return contract, bin_id, time_seconds, cache_pressure, dispatch_event, columns


def build_design(contract: dict, cache_pressure: np.ndarray, dispatch_event: np.ndarray) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
    n = dispatch_event.size
    feature_columns: dict[str, np.ndarray] = {
        "intercept": np.ones(n, dtype=np.float64),
        "cache_pressure": cache_pressure.astype(np.float64, copy=True),
    }
    history_columns: dict[str, np.ndarray] = {}
    for feature, window in contract["history_windows_previous_bins"].items():
        low, high = (int(window[0]), int(window[1]))
        require(1 <= low <= high, f"invalid history window for {feature}")
        values = np.zeros(n, dtype=np.float64)
        for index in range(n):
            start = max(0, index - high)
            stop = max(0, index - low + 1)
            values[index] = dispatch_event[start:stop].sum()
        feature_columns[feature] = values
        history_columns[feature] = values
    model_matrices: dict[str, np.ndarray] = {}
    for model, features in contract["models"].items():
        require(features and features[0] == "intercept", f"{model} must begin with intercept")
        require(len(features) == len(set(features)), f"{model} contains duplicate features")
        require(all(feature in feature_columns for feature in features), f"{model} references an unknown feature")
        model_matrices[model] = np.column_stack([feature_columns[feature] for feature in features])
    return model_matrices, history_columns


def fit_poisson_irls(X: np.ndarray, y: np.ndarray, contract: dict) -> tuple[np.ndarray, int, bool]:
    dt = float(contract["bin_width_seconds"])
    ridge_lambda = float(contract["ridge_lambda"])
    max_iterations = int(contract["irls_max_iterations"])
    tolerance = float(contract["irls_tolerance"])
    eta_low, eta_high = (float(value) for value in contract["eta_clip"])
    beta = np.zeros(X.shape[1], dtype=np.float64)
    beta[0] = math.log(max(float(y.mean()) / dt, 1e-9))
    penalty = np.eye(X.shape[1], dtype=np.float64)
    penalty[0, 0] = 0.0
    for iteration in range(1, max_iterations + 1):
        eta = np.clip(X @ beta + math.log(dt), eta_low, eta_high)
        mu = np.exp(eta)
        weight = np.maximum(mu, 1e-10)
        working = eta + (y - mu) / weight - math.log(dt)
        lhs = X.T @ (weight[:, None] * X) + ridge_lambda * penalty
        rhs = X.T @ (weight * working)
        updated = np.linalg.solve(lhs, rhs)
        if float(np.max(np.abs(updated - beta))) < tolerance:
            return updated, iteration, True
        beta = updated
    return beta, max_iterations, False


def poisson_deviance(y: np.ndarray, mu: np.ndarray) -> float:
    require(np.all(mu > 0) and np.all(np.isfinite(mu)), "predicted count must be positive and finite")
    term = np.zeros_like(mu)
    mask = y > 0
    term[mask] = y[mask] * np.log(y[mask] / mu[mask])
    return float(2.0 * np.sum(term - (y - mu)))


def validate_folds(contract: dict, n: int) -> list[dict]:
    folds = list(contract["forward_folds"])
    require(len(folds) > 0, "at least one forward fold is required")
    previous_test_end = None
    for expected_number, fold in enumerate(folds, start=1):
        train_end = int(fold["train_end_bin"])
        test_start = int(fold["test_start_bin"])
        test_end = int(fold["test_end_bin"])
        require(int(fold["fold"]) == expected_number, "fold numbers must be continuous")
        require(train_end >= 1 and test_start == train_end + 1 and test_end >= test_start and test_end <= n, "invalid forward fold boundary")
        if previous_test_end is not None:
            require(train_end == previous_test_end, "each training prefix must end at the previous test boundary")
        previous_test_end = test_end
    require(previous_test_end == n, "the final fold must end at the final bin")
    return folds


def conditional_mean(X: np.ndarray, beta: np.ndarray, contract: dict) -> np.ndarray:
    dt = float(contract["bin_width_seconds"])
    eta_low, eta_high = (float(value) for value in contract["eta_clip"])
    return np.exp(np.clip(X @ beta + math.log(dt), eta_low, eta_high))


def bool_text(value: bool) -> str:
    return "true" if value else "false"


def write_csv(path: Path, fieldnames: list[str], rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def calculate(input_root: Path) -> tuple[dict[str, list[dict]], dict]:
    contract, bin_id, time_seconds, cache_pressure, y, columns = read_inputs(input_root)
    n = len(y)
    folds = validate_folds(contract, n)
    model_matrices, history_columns = build_design(contract, cache_pressure, y)
    fold_rows: list[dict] = []
    mean_deviance: dict[str, float] = {}
    all_converged = True
    for model, X in model_matrices.items():
        deviations = []
        for fold in folds:
            train_end = int(fold["train_end_bin"])
            test_start = int(fold["test_start_bin"])
            test_end = int(fold["test_end_bin"])
            beta, iterations, converged = fit_poisson_irls(X[:train_end], y[:train_end], contract)
            all_converged = all_converged and converged
            mu_test = conditional_mean(X[test_start - 1:test_end], beta, contract)
            deviation = poisson_deviance(y[test_start - 1:test_end], mu_test)
            deviations.append(deviation)
            fold_rows.append({
                "model": model,
                "fold": int(fold["fold"]),
                "train_end_bin": train_end,
                "test_start_bin": test_start,
                "test_end_bin": test_end,
                "test_events": int(y[test_start - 1:test_end].sum()),
                "holdout_deviance": deviation,
                "irls_iterations": iterations,
                "converged": bool_text(converged),
            })
        mean_deviance[model] = float(np.mean(deviations))
    ordered_models = sorted(model_matrices, key=lambda model: (mean_deviance[model], model))
    tie_tolerance = float(contract.get("selection_tie_tolerance", 0.0))
    require(len(ordered_models) == 1 or mean_deviance[ordered_models[1]] - mean_deviance[ordered_models[0]] > tie_tolerance, "selected model is not unique")
    selected_model = ordered_models[0]
    summary_rows = [
        {
            "model": model,
            "feature_count": len(contract["models"][model]),
            "mean_holdout_deviance": mean_deviance[model],
            "rank": rank,
            "selected": bool_text(rank == 1),
        }
        for rank, model in enumerate(ordered_models, start=1)
    ]
    selected_X = model_matrices[selected_model]
    beta, _, full_converged = fit_poisson_irls(selected_X, y, contract)
    coefficient_rows = [
        {
            "model": selected_model,
            "feature": feature,
            "coefficient": float(value),
            "penalized": bool_text(feature != "intercept"),
        }
        for feature, value in zip(contract["models"][selected_model], beta)
    ]
    mu = conditional_mean(selected_X, beta, contract)
    event_bins = np.flatnonzero(y > 0) + 1
    rescaled_rows: list[dict] = []
    previous = 0
    for sequence, current in enumerate(event_bins, start=1):
        integrated = float(mu[previous:current].sum())
        rescaled_rows.append({
            "event_sequence": sequence,
            "interval_start_bin": previous + 1,
            "dispatch_bin": int(current),
            "integrated_hazard": integrated,
            "z_uniform": 1.0 - math.exp(-integrated),
        })
        previous = int(current)
    z = np.sort(np.array([row["z_uniform"] for row in rescaled_rows], dtype=np.float64))
    event_count = len(z)
    ks_left = np.max(np.arange(1, event_count + 1) / event_count - z)
    ks_right = np.max(z - np.arange(0, event_count) / event_count)
    ks_d = float(max(ks_left, ks_right))
    ks_bound = float(contract["time_rescaling_ks_constant"]) / math.sqrt(event_count)
    ks_rows = [{
        "selected_model": selected_model,
        "event_count": event_count,
        "ks_d": ks_d,
        "ks_bound_95": ks_bound,
        "ks_pass": bool_text(ks_d <= ks_bound),
        "mean_z": float(z.mean()),
    }]
    history_exact = True
    for feature, (low, high) in contract["history_windows_previous_bins"].items():
        expected = np.zeros(n, dtype=np.float64)
        for index in range(n):
            expected[index] = y[max(0, index - int(high)):max(0, index - int(low) + 1)].sum()
        history_exact = history_exact and np.array_equal(history_columns[feature], expected)
    rank_values = [row["rank"] for row in summary_rows]
    selected_rows = [row for row in summary_rows if row["selected"] == "true"]
    interval_starts = [row["interval_start_bin"] for row in rescaled_rows]
    expected_starts = [1] + [row["dispatch_bin"] + 1 for row in rescaled_rows[:-1]]
    invariants = {
        "input_schema_exact": columns == list(contract["required_columns"]),
        "bin_sequence_exact": np.array_equal(bin_id, np.arange(1, n + 1)),
        "time_grid_exact": bool(np.max(np.abs(time_seconds - bin_id * float(contract["bin_width_seconds"]))) <= 1e-12),
        "numeric_input_is_finite": bool(np.all(np.isfinite(time_seconds)) and np.all(np.isfinite(cache_pressure))),
        "binary_event_count_matches_contract": bool(np.all((y == 0) | (y == 1)) and int(y.sum()) == int(contract["event_count"])),
        "history_windows_are_strictly_past": bool(history_exact),
        "model_feature_sets_match_contract": all(model_matrices[model].shape[1] == len(features) for model, features in contract["models"].items()),
        "forward_fold_contract_is_valid": len(folds) == len(contract["forward_folds"]) and int(folds[-1]["test_end_bin"]) == n,
        "every_model_has_every_forward_fold": len(fold_rows) == len(model_matrices) * len(folds),
        "all_training_prefixes_end_before_tests": all(row["train_end_bin"] < row["test_start_bin"] for row in fold_rows),
        "all_irls_fits_converge": bool(all_converged and full_converged),
        "summary_rank_follows_holdout_deviance": rank_values == list(range(1, len(summary_rows) + 1)) and [row["mean_holdout_deviance"] for row in summary_rows] == sorted(mean_deviance.values()),
        "selected_model_is_unique": len(selected_rows) == 1 and selected_rows[0]["model"] == selected_model,
        "selected_coefficients_match_model": len(coefficient_rows) == len(contract["models"][selected_model]),
        "intercept_is_unpenalized": coefficient_rows[0]["feature"] == "intercept" and coefficient_rows[0]["penalized"] == "false" and all(row["penalized"] == "true" for row in coefficient_rows[1:]),
        "one_rescaled_value_per_event": len(rescaled_rows) == int(y.sum()),
        "rescaled_intervals_are_contiguous": interval_starts == expected_starts,
        "rescaled_values_are_open_unit_interval": bool(np.all((z > 0) & (z < 1))),
        "ks_bound_uses_event_count": abs(ks_bound - float(contract["time_rescaling_ks_constant"]) / math.sqrt(int(y.sum()))) <= 1e-12,
        "ks_decision_matches_statistic": (ks_rows[0]["ks_pass"] == "true") == (ks_d <= ks_bound),
    }
    require(bool(invariants) and all(invariants.values()), "validation invariants must be nonempty and true")
    validation = {
        "result": "PASS" if all(invariants.values()) else "FAIL",
        "controls": {
            "bins": n,
            "events": int(y.sum()),
            "fold_rows": len(fold_rows),
            "models": len(summary_rows),
            "coefficient_rows": len(coefficient_rows),
            "rescaled_dispatches": len(rescaled_rows),
            "selected_model": selected_model,
            "ks_d": ks_d,
            "ks_bound_95": ks_bound,
        },
        "invariants": invariants,
    }
    return {
        "fold_metrics.csv": fold_rows,
        "model_summary.csv": summary_rows,
        "selected_coefficients.csv": coefficient_rows,
        "rescaled_dispatches.csv": rescaled_rows,
        "ks_diagnostic.csv": ks_rows,
    }, validation


def write_results(results_root: Path, tables: dict[str, list[dict]], validation: dict) -> None:
    results_root.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix=".cache_fill_results_", dir=results_root.parent))
    try:
        for name, rows in tables.items():
            require(rows, f"{name} cannot be empty")
            write_csv(temporary / name, list(rows[0]), rows)
        (temporary / "validation.json").write_text(json.dumps(validation, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        temporary.replace(results_root)
    except Exception:
        if temporary.exists():
            shutil.rmtree(temporary)
        raise


def main() -> int:
    arguments = parse_arguments()
    input_root = Path(arguments.input_root).resolve()
    results_root = Path(arguments.results_root).resolve()
    reset_results(results_root)
    try:
        tables, validation = calculate(input_root)
        require(validation["result"] == "PASS", "dynamic validation failed")
        write_results(results_root, tables, validation)
    except Exception as error:
        if results_root.exists():
            shutil.rmtree(results_root)
        print(f"ERROR: {error}", file=sys.stderr)
        return 2
    print(json.dumps(validation, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
