#边缘缓存填充点过程关联评估

将输入包和reference解压到同一目录后，应得到并列的`input_data`与`output`。MATLAB实现只依赖Base MATLAB；Python程序使用NumPy独立重放同一公开合同，用于没有MATLAB运行时的数值预复核，不替代MATLAB交付。

## MATLAB入口

在MATLAB中把`output/matlab`加入路径后执行：

```matlab
addpath(fullfile(pwd,"output","matlab"));
verify_cache_fill_glm(fullfile(pwd,"input_data"),fullfile(pwd,"output","results"));
```

## Windows11PowerShell独立重放

以下命令在含空格路径中直接运行，不需要WSL。依赖为Python3.12或兼容版本和NumPy2.3.5：

```powershell
python ".\output\tools\replay_cache_fill.py" --input-root ".\input_data" --results-root ".\output\results"
python -m unittest discover ".\output\tests" -p "test_results.py"
```

## macOS或Linux独立重放

```sh
python3 "./output/tools/replay_cache_fill.py" --input-root "./input_data" --results-root "./output/results"
python3 -m unittest discover "./output/tests" -p "test_results.py"
```

两个入口都会重建五张CSV和`validation.json`。比较MATLAB与Python结果时，字符串、布尔值、主键和行集合必须一致；浮点字段使用`model_contract.json`中的`validation_numeric_tolerance`。无效输入应非零结束，且结果目录中不保留CSV或JSON。
