function result = random_holdout_glm(inputRoot)
% 故障起点：随机打散时间、依赖 glmfit、没有 offset，也没有调度历史项。
T = readtable(fullfile(inputRoot,"cache_fill_bins.csv"));
rng(7);
order = randperm(height(T));
train = order(1:round(0.8*height(T)));
test = order(round(0.8*height(T))+1:end);
b = glmfit(T.cache_pressure(train),T.dispatch_event(train),"poisson");
result = mean((T.dispatch_event(test)-glmval(b,T.cache_pressure(test),"log")).^2);
end
