function verify_cache_fill_glm(inputRoot,outputRoot)
if isfolder(outputRoot), rmdir(outputRoot,"s"); end
run_cache_fill_glm(inputRoot,outputRoot);
C0 = jsondecode(fileread(fullfile(inputRoot,"model_contract.json")));
F = readtable(fullfile(outputRoot,"fold_metrics.csv"));
S = readtable(fullfile(outputRoot,"model_summary.csv"));
C = readtable(fullfile(outputRoot,"selected_coefficients.csv"));
R = readtable(fullfile(outputRoot,"rescaled_dispatches.csv"));
K = readtable(fullfile(outputRoot,"ks_diagnostic.csv"));
V = jsondecode(fileread(fullfile(outputRoot,"validation.json")));
modelNames = string(fieldnames(C0.models));
selected = string(S.model(1));
assert(height(F)==numel(modelNames)*numel(C0.forward_folds) && height(S)==numel(modelNames));
assert(height(C)==numel(C0.models.(char(selected))) && height(R)==C0.event_count);
assert(all(diff(S.mean_holdout_deviance)>=0) && sum(string(S.selected)=="true")==1);
assert(K.event_count==C0.event_count && abs(K.ks_bound_95-C0.time_rescaling_ks_constant/sqrt(C0.event_count))<=1e-12);
assert(string(V.result)=="PASS" && ~isempty(fieldnames(V.invariants)) && all(cellfun(@(value) logical(value),struct2cell(V.invariants))));
disp("MATLAB edge-cache dispatch point-process verification PASS");
end
