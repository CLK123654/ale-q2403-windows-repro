import csv
import json
import math
import os
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INPUT = Path(os.environ.get("ALE_INPUT_ROOT", ROOT.parent / "input_data")).resolve()
RESULTS = Path(os.environ.get("ALE_RESULTS_ROOT", ROOT / "results")).resolve()
CONTRACT = json.loads((INPUT / "model_contract.json").read_text(encoding="utf-8"))
TOLERANCE = float(CONTRACT["validation_numeric_tolerance"])


def read_csv(name):
    with (RESULTS / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


class CacheFillPointProcessTests(unittest.TestCase):
    def test_validation_has_derived_invariants(self):
        validation = json.loads((RESULTS / "validation.json").read_text(encoding="utf-8"))
        self.assertEqual(validation["result"], "PASS")
        self.assertGreater(len(validation["invariants"]), 0)
        self.assertTrue(all(validation["invariants"].values()))
        self.assertEqual(validation["controls"]["bins"], CONTRACT["bin_count"])
        self.assertEqual(validation["controls"]["events"], CONTRACT["event_count"])

    def test_forward_folds_are_contract_prefixes(self):
        rows = read_csv("fold_metrics.csv")
        models = list(CONTRACT["models"])
        folds = CONTRACT["forward_folds"]
        self.assertEqual(len(rows), len(models) * len(folds))
        expected = sorted((fold["train_end_bin"], fold["test_start_bin"], fold["test_end_bin"]) for fold in folds)
        actual = sorted({(int(row["train_end_bin"]), int(row["test_start_bin"]), int(row["test_end_bin"])) for row in rows})
        self.assertEqual(actual, expected)
        self.assertTrue(all(int(row["train_end_bin"]) < int(row["test_start_bin"]) for row in rows))

    def test_model_selection_is_derived_from_holdout_deviance(self):
        folds = read_csv("fold_metrics.csv")
        summary = read_csv("model_summary.csv")
        grouped = {}
        for row in folds:
            grouped.setdefault(row["model"], []).append(float(row["holdout_deviance"]))
        expected = sorted(grouped, key=lambda model: (sum(grouped[model]) / len(grouped[model]), model))
        self.assertEqual([row["model"] for row in summary], expected)
        self.assertEqual([int(row["rank"]) for row in summary], list(range(1, len(summary) + 1)))
        self.assertEqual([row["selected"] for row in summary].count("true"), 1)
        for row in summary:
            mean = sum(grouped[row["model"]]) / len(grouped[row["model"]])
            self.assertLessEqual(abs(float(row["mean_holdout_deviance"]) - mean), TOLERANCE)

    def test_coefficients_follow_selected_model_features(self):
        summary = read_csv("model_summary.csv")
        selected = next(row["model"] for row in summary if row["selected"] == "true")
        coefficients = read_csv("selected_coefficients.csv")
        self.assertEqual([row["feature"] for row in coefficients], CONTRACT["models"][selected])
        self.assertTrue(all(row["model"] == selected for row in coefficients))
        self.assertEqual(coefficients[0]["penalized"], "false")
        self.assertTrue(all(row["penalized"] == "true" for row in coefficients[1:]))

    def test_dispatch_intervals_close_at_each_event(self):
        rows = read_csv("rescaled_dispatches.csv")
        self.assertEqual(len(rows), CONTRACT["event_count"])
        self.assertEqual([int(row["event_sequence"]) for row in rows], list(range(1, len(rows) + 1)))
        for index, row in enumerate(rows):
            self.assertGreater(float(row["z_uniform"]), 0)
            self.assertLess(float(row["z_uniform"]), 1)
            expected_start = 1 if index == 0 else int(rows[index - 1]["dispatch_bin"]) + 1
            self.assertEqual(int(row["interval_start_bin"]), expected_start)

    def test_two_sided_ks_is_recomputed(self):
        rescaled = sorted(float(row["z_uniform"]) for row in read_csv("rescaled_dispatches.csv"))
        n = len(rescaled)
        ks_d = max(
            max((index + 1) / n - value for index, value in enumerate(rescaled)),
            max(value - index / n for index, value in enumerate(rescaled)),
        )
        diagnostic = read_csv("ks_diagnostic.csv")[0]
        self.assertLessEqual(abs(ks_d - float(diagnostic["ks_d"])), TOLERANCE)
        expected_bound = float(CONTRACT["time_rescaling_ks_constant"]) / math.sqrt(n)
        self.assertLessEqual(abs(float(diagnostic["ks_bound_95"]) - expected_bound), TOLERANCE)
        self.assertEqual(diagnostic["ks_pass"] == "true", ks_d <= expected_bound)


if __name__ == "__main__":
    unittest.main()
