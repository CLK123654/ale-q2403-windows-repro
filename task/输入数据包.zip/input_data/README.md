#输入边界

这组离线材料描述边缘节点在24秒观测窗内的缓存填充调度，不对应真实用户、域名、流量、节点或生产告警。cache_fill_bins.csv按5ms分箱，共4800行；cache_pressure是归一化的回源压力信号，dispatch_event只取0或1，合计380次填充调度。

`model_contract.json`公开输入列、三个模型、三个前向折、ridge与IRLS参数、历史窗口和时间缩放阈值。必须保持`bin_id=1:4800`、`time_seconds=bin_id*0.005`和原始行序；三个测试段都只能使用其之前的完整前缀拟合。

M2的三个历史特征只读取当前bin之前的第1、2–6、7–16个bin。线性预测器必须包含`log(0.005)` offset，截距不得施加ridge。最终模型按三个测试段的平均Poisson deviance唯一选出，再以全量拟合的条件强度对每次调度做时间缩放。

所有输入只读。`starter/random_holdout_glm.m`故意随机打散时间、遗漏offset、忽略历史并调用不允许的`glmfit`，只能作为待修复起点，不能作为答案。

最终交付根目录为`output`。其中包含`README.md`；`matlab`目录下的`run_cache_fill_glm.m`、`build_dispatch_design.m`、`fit_poisson_irls.m`、`poisson_deviance.m`、`rescale_dispatch_events.m`、`verify_cache_fill_glm.m`；`tools/replay_cache_fill.py`；`results`目录下的`fold_metrics.csv`、`model_summary.csv`、`selected_coefficients.csv`、`rescaled_dispatches.csv`、`ks_diagnostic.csv`、`validation.json`；以及`tests/test_results.py`。不要在交付根内复制输入或保留缓存文件。
